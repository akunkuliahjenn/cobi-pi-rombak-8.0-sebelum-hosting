<?php
// includes/footer.php
// File ini berisi bagian penutup HTML.
?>
</body>
</html>
